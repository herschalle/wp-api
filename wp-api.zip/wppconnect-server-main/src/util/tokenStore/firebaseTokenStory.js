/*var FirebaseTokenStore = function (client) {
  this.tokenStore = {
    getToken: (sessionName) => {
      return null;
    },
    setToken: (sessionName, tokenData) => {
      return false;
    },
    removeToken: (sessionName) => {
      return false;
    },
    listTokens: () => {
      return [];
    },
  };
};*/

module.exports = null; // FirebaseTokenStore;
